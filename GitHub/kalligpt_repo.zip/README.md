# KalliGPT 1.0

Digitale Klartext-Plattform von Kalli Turban – mit Supabase, OpenAI und Gradio.
Frage KalliGPT, durchsuche politische Anträge und erhalte fundierte Antworten.